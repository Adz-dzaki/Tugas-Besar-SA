document.getElementById('knapsackForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const maxWeight = parseInt(document.getElementById('maxWeight').value);
    const itemCount = parseInt(document.getElementById('itemCount').value);
    const items = [];
    
    for (let i = 0; i < itemCount; i++) {
        const name = document.getElementById(`itemName${i}`).value;
        const weight = parseInt(document.getElementById(`itemWeight${i}`).value);
        const profit = parseInt(document.getElementById(`itemProfit${i}`).value);
        items.push({ name, weight, profit });
    }
    
    const bruteForceWeightResults = bruteForceKnapsackByWeight(items, maxWeight);
    const bruteForceProfitResults = bruteForceKnapsackByProfit(items, maxWeight);
    const greedyWeightResults = greedyKnapsackByWeight(items, maxWeight);
    const greedyProfitResults = greedyKnapsackByProfit(items, maxWeight);
    
    displayResults(bruteForceWeightResults, bruteForceProfitResults, greedyWeightResults, greedyProfitResults);
});

document.getElementById('itemCount').addEventListener('input', function() {
    const itemCount = parseInt(this.value);
    const itemInputs = document.getElementById('itemInputs');
    itemInputs.innerHTML = '';
    
    for (let i = 0; i < itemCount; i++) {
        itemInputs.innerHTML += `
            <label for="itemName${i}">Item ${i + 1} Name:</label>
            <input type="text" id="itemName${i}" required>
            <label for="itemWeight${i}">Item ${i + 1} Weight:</label>
            <input type="number" id="itemWeight${i}" required>
            <label for="itemProfit${i}">Item ${i + 1} Profit:</label>
            <input type="number" id="itemProfit${i}" required>
        `;
    }
});

function bruteForceKnapsackByWeight(items, maxWeight) {
    const n = items.length;
    let bestSolution = { items: [], weight: 0, profit: 0 };

    function search(solution, index, currentWeight, currentProfit) {
        if (currentWeight <= maxWeight) {
            if (currentProfit > bestSolution.profit ||
                (currentProfit === bestSolution.profit && currentWeight < bestSolution.weight)) {
                bestSolution = { items: solution.slice(), weight: currentWeight, profit: currentProfit };
            }
        }

        if (index === n) return;

        // Include the current item
        solution.push(items[index]);
        search(solution, index + 1, currentWeight + items[index].weight, currentProfit + items[index].profit);
        solution.pop();

        // Skip the current item
        search(solution, index + 1, currentWeight, currentProfit);
    }

    search([], 0, 0, 0);
    return bestSolution;
}

function bruteForceKnapsackByProfit(items, maxWeight) {
    const n = items.length;
    let bestSolution = { items: [], weight: 0, profit: 0 };

    function search(solution, index, currentWeight, currentProfit) {
        if (currentWeight <= maxWeight && currentProfit > bestSolution.profit) {
            bestSolution = { items: solution.slice(), weight: currentWeight, profit: currentProfit };
        }

        if (index === n) return;

        // Include the current item
        if (currentWeight + items[index].weight <= maxWeight) {
            solution.push(items[index]);
            search(solution, index + 1, currentWeight + items[index].weight, currentProfit + items[index].profit);
            solution.pop();
        }

        // Skip the current item
        search(solution, index + 1, currentWeight, currentProfit);
    }

    search([], 0, 0, 0);
    return bestSolution;
}

function greedyKnapsackByWeight(items, maxWeight) {
    items.sort((a, b) => a.weight - b.weight);

    let totalWeight = 0;
    let totalProfit = 0;
    const selectedItems = [];

    for (const item of items) {
        if (totalWeight + item.weight <= maxWeight) {
            selectedItems.push(item);
            totalWeight += item.weight;
            totalProfit += item.profit;
        }
    }

    return { items: selectedItems, weight: totalWeight, profit: totalProfit };
}

function greedyKnapsackByProfit(items, maxWeight) {
    items.sort((a, b) => b.profit - a.profit);

    let totalWeight = 0;
    let totalProfit = 0;
    const selectedItems = [];

    for (const item of items) {
        if (totalWeight + item.weight <= maxWeight) {
            selectedItems.push(item);
            totalWeight += item.weight;
            totalProfit += item.profit;
        }
    }

    return { items: selectedItems, weight: totalWeight, profit: totalProfit };
}

function displayResults(bruteForceWeightResults, bruteForceProfitResults, greedyWeightResults, greedyProfitResults) {
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = `
        <h2>Results</h2>
        <h3>Brute Force - By Weight:</h3>
        <p>Items: ${bruteForceWeightResults.items.map(item => item.name).join(', ')}</p>
        <p>Total Weight: ${bruteForceWeightResults.weight}</p>
        <p>Total Profit: ${bruteForceWeightResults.profit}</p>
        <h3>Brute Force - By Profit:</h3>
        <p>Items: ${bruteForceProfitResults.items.map(item => item.name).join(', ')}</p>
        <p>Total Weight: ${bruteForceProfitResults.weight}</p>
        <p>Total Profit: ${bruteForceProfitResults.profit}</p>
        <h3>Greedy - By Weight:</h3>
        <p>Items: ${greedyWeightResults.items.map(item => item.name).join(', ')}</p>
        <p>Total Weight: ${greedyWeightResults.weight}</p>
        <p>Total Profit: ${greedyWeightResults.profit}</p>
        <h3>Greedy - By Profit:</h3>
        <p>Items: ${greedyProfitResults.items.map(item => item.name).join(', ')}</p>
        <p>Total Weight: ${greedyProfitResults.weight}</p>
        <p>Total Profit: ${greedyProfitResults.profit}</p>
    `;
}
